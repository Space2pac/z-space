class Car {

    static type = 'Universal'

    constructor(obj) {
        this.name = obj.name
        this.ageAuto = obj.ageAuto
        this.automaticBox = obj.automaticBox
    }
}


const car = new Car({
    name: 'Car',
    ageAuto: 5,
    automaticBox: true
})

console.log(car);

class Mazda extends Car {
    constructor(obj) {
        super(obj)
        this.name = obj.name
        this.ageAuto = obj.ageAuto
        this.automaticBox = obj.automaticBox
        this.price = obj.price
    }
}

const mazda = new Mazda({
    name: 'Mazda',
    ageAuto: 3,
    automaticBox: true,
    price: '35000$'
})

console.log(mazda);









let box = document.querySelector('.scale__room')
let ball = document.querySelector('.nike__FOG')
let mouseEnter = false;
box.addEventListener('mouseenter', (e) => {
    mouseEnter = true;

})
// box.addEventListener('mouseleave', (e) => {
//     ball.style.transform = `scale(1)`;
// })

box.addEventListener('mousemove', (e) => {
    
    if (mouseEnter) {

    const speed = ball.getAttribute('data-speed')
    //   console.log(e);
    //   const x = (window.innerWidth - e.pageX * speed ) / 100
    //   const y = (window.innerWidth - e.pageY * speed ) / 100
    let centerX = box.clientWidth / 2;
    let centerY = box.clientHeight / 2;
    let x = e.offsetX
    let y = e.offsetY


    console.log(x, y);
    ball.style.transform = `translate(${(centerX-x) / 1.6}px, ${(centerY-y) / 1.6}px) scale(1.6)`
    //   ball.style.transition = '.4s'
    }
    
})
box.addEventListener('mouseout', (e) => {
    console.log(1);
    ball.style.transform = `translate(0, 0) scale(1)`
})

